#!/bin/bash

# Resnet 18
CUDA_VISIBLE_DEVICES=0 python AT_Res18_cifar10.py --is_Train --GPU_IDs 0 1 --network _ \
                                                        --exp_path ./experiments/Cln_Res18_cifar10 --attack_loss CE
CUDA_VISIBLE_DEVICES=0 python AT_Res18_cifar10.py --is_Train --is_AdvTr --GPU_IDs 0 --network _ \
                                                        --exp_path ./experiments/AT_Res18_cifar10__ --attack_loss CE

#
#  CIFS
#
CUDA_VISIBLE_DEVICES=0,1 python AT_Res18_cifar10.py --is_Train --GPU_IDs 0 1 --network CIFS --exp_path ./experiments/cln/Cln_Res18_cifar10_CIFS

CUDA_VISIBLE_DEVICES=0,1 python AT_Res18_cifar10.py --is_Train --is_AdvTr --GPU_IDs 0 1 --network CIFS \
                                                        --resume --checkpoint ./experiments/cln/Cln_Res18_cifar10_CIFS/nets/ckp_best.pt \
                                                        --exp_path ./experiments/AT_Res18_cifar10_CIFS --attack_loss Joint

CUDA_VISIBLE_DEVICES=0 python AT_Res18_cifar10_test.py --GPU_IDs 0 --network CIFS \
                                                        --which_model ./experiments/AT_Res18_cifar10_CIFS/nets/ckp_best.pt --is_attack 1 --is_joint 1 --beta_atk 2
























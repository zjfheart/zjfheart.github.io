import torch.nn as nn
import torch.nn.functional as F

class joint_CE_loss(nn.Module):
    def __init__(self, beta=2, is_joint=True) -> None:
        super().__init__()
        self.beta = beta
        self.is_joint = is_joint
        
    def forward(self, logits_tuple, target):
        logits_final, logits_raw_list = logits_tuple
        loss = 0
        if self.is_joint:
            if len(logits_raw_list) > 0:
                for logits in logits_raw_list:
                    loss += F.cross_entropy(logits, target)
                loss = (self.beta/len(logits_raw_list)) * loss
        loss += F.cross_entropy(logits_final, target)
        # loss = loss * /(self.beta + 1)
        loss = loss * 3/(self.beta + 1)
        return loss